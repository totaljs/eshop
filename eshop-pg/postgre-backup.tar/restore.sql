--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.tbl_product_linker;
DROP INDEX public.tbl_page_widget_id;
DROP INDEX public.tbl_page_url;
ALTER TABLE ONLY public.tbl_widget DROP CONSTRAINT tbl_widget_pkey;
ALTER TABLE ONLY public.tbl_visitor DROP CONSTRAINT tbl_visitor_pkey;
ALTER TABLE ONLY public.tbl_user DROP CONSTRAINT tbl_user_pkey;
ALTER TABLE ONLY public.tbl_product DROP CONSTRAINT tbl_product_pkey;
ALTER TABLE ONLY public.tbl_page DROP CONSTRAINT tbl_page_pkey;
ALTER TABLE ONLY public.tbl_order DROP CONSTRAINT tbl_order_pkey;
ALTER TABLE ONLY public.tbl_newsletter DROP CONSTRAINT tbl_newsletter_pkey;
ALTER TABLE ONLY public.tbl_contactform DROP CONSTRAINT tbl_contactform_pkey;
ALTER TABLE ONLY public.tbl_common DROP CONSTRAINT tbl_common_pkey;
SELECT pg_catalog.lo_unlink('21442');
SELECT pg_catalog.lo_unlink('21441');
SELECT pg_catalog.lo_unlink('21385');
SELECT pg_catalog.lo_unlink('21384');
SELECT pg_catalog.lo_unlink('21377');
SELECT pg_catalog.lo_unlink('21376');
SELECT pg_catalog.lo_unlink('21375');
SELECT pg_catalog.lo_unlink('21374');
SELECT pg_catalog.lo_unlink('21373');
SELECT pg_catalog.lo_unlink('21372');
SELECT pg_catalog.lo_unlink('21371');
SELECT pg_catalog.lo_unlink('21112');
SELECT pg_catalog.lo_unlink('21111');
SELECT pg_catalog.lo_unlink('21110');
SELECT pg_catalog.lo_unlink('21109');
SELECT pg_catalog.lo_unlink('21108');
DROP TABLE public.tbl_widget;
DROP TABLE public.tbl_visitor;
DROP TABLE public.tbl_user;
DROP TABLE public.tbl_product;
DROP TABLE public.tbl_page_widget;
DROP TABLE public.tbl_page;
DROP TABLE public.tbl_order_product;
DROP TABLE public.tbl_order;
DROP TABLE public.tbl_newsletter;
DROP TABLE public.tbl_contactform;
DROP TABLE public.tbl_common;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tbl_common; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_common (
    id character varying(30) NOT NULL,
    body json
);


ALTER TABLE tbl_common OWNER TO petersirka;

--
-- Name: tbl_contactform; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_contactform (
    id character varying(10) NOT NULL,
    firstname character varying(40),
    lastname character varying(40),
    email character varying(200),
    message text,
    phone character varying(20),
    language character varying(3),
    ip character varying(80),
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_contactform OWNER TO petersirka;

--
-- Name: tbl_newsletter; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_newsletter (
    email character varying(200) NOT NULL,
    ip character varying(80),
    language character varying(3),
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_newsletter OWNER TO petersirka;

--
-- Name: tbl_order; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_order (
    id character varying(10) NOT NULL,
    iduser character varying(10),
    status character varying(100),
    delivery character varying(30),
    firstname character varying(40),
    lastname character varying(40),
    email character varying(200),
    phone character varying(20),
    address character varying(1000),
    message character varying(500),
    search character varying(80),
    note character varying(500),
    ip character varying(80),
    price real,
    count smallint,
    iscompleted boolean,
    ispaid boolean,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    datecompleted timestamp without time zone,
    datepaid timestamp without time zone
);


ALTER TABLE tbl_order OWNER TO petersirka;

--
-- Name: tbl_order_product; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_order_product (
    idorder character varying(10),
    idproduct character varying(10),
    name character varying(80),
    reference character varying(20),
    pictures character varying(100),
    price real,
    count smallint
);


ALTER TABLE tbl_order_product OWNER TO petersirka;

--
-- Name: tbl_page; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_page (
    id character varying(10) NOT NULL,
    parent character varying(10),
    pictures character varying(500),
    navigations character varying(1000),
    tags character varying(500),
    template character varying(30),
    language character varying(3),
    name character varying(50),
    url character varying(200),
    search character varying(2000),
    icon character varying(20),
    perex character varying(500),
    title character varying(100),
    priority smallint,
    body text,
    ispartial boolean,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_page OWNER TO petersirka;

--
-- Name: tbl_page_widget; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_page_widget (
    idpage character varying(10),
    idwidget character varying(10),
    settings character varying(500)
);


ALTER TABLE tbl_page_widget OWNER TO petersirka;

--
-- Name: tbl_product; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_product (
    id character varying(10) NOT NULL,
    pictures character varying(500),
    reference character varying(20),
    linker character varying(300),
    linker_category character varying(300),
    category character varying(50),
    name character varying(50),
    search character varying(80),
    price real,
    body text,
    istop boolean,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    linker_manufacturer character varying(50),
    manufacturer character varying(50)
);


ALTER TABLE tbl_product OWNER TO petersirka;

--
-- Name: tbl_user; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_user (
    id character varying(10) NOT NULL,
    idfacebook character varying(30),
    idgoogle character varying(30),
    idlinkedin character varying(30),
    idinstagram character varying(30),
    idyandex character varying(30),
    iddropbox character varying(30),
    idvk character varying(30),
    idyahoo character varying(30),
    idlive character varying(30),
    ip character varying(80),
    name character varying(50),
    search character varying(80),
    email character varying(200),
    gender character varying(20),
    countlogin integer,
    isremoved boolean DEFAULT false,
    datelogged timestamp without time zone,
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_user OWNER TO petersirka;

--
-- Name: tbl_visitor; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_visitor (
    id character varying(20) NOT NULL,
    day smallint DEFAULT 0,
    month smallint DEFAULT 0,
    year smallint DEFAULT 0,
    pages integer DEFAULT 0,
    hits integer DEFAULT 0,
    "unique" integer DEFAULT 0,
    uniquemonth integer DEFAULT 0,
    count integer DEFAULT 0,
    search integer DEFAULT 0,
    direct integer DEFAULT 0,
    social integer DEFAULT 0,
    unknown integer DEFAULT 0,
    advert integer DEFAULT 0,
    desktop integer DEFAULT 0,
    mobile integer DEFAULT 0,
    visitors integer DEFAULT 0,
    users integer DEFAULT 0,
    orders integer DEFAULT 0,
    contactforms integer DEFAULT 0,
    newsletter integer DEFAULT 0,
    dateupdated timestamp without time zone,
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_visitor OWNER TO petersirka;

--
-- Name: tbl_widget; Type: TABLE; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE TABLE tbl_widget (
    id character varying(10) NOT NULL,
    name character varying(50),
    icon character varying(20),
    body text,
    istemplate boolean,
    datecreated timestamp without time zone DEFAULT now(),
    isremoved boolean DEFAULT false
);


ALTER TABLE tbl_widget OWNER TO petersirka;

--
-- Name: 21108; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21108');


ALTER LARGE OBJECT 21108 OWNER TO testuser;

--
-- Name: 21109; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21109');


ALTER LARGE OBJECT 21109 OWNER TO testuser;

--
-- Name: 21110; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21110');


ALTER LARGE OBJECT 21110 OWNER TO testuser;

--
-- Name: 21111; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21111');


ALTER LARGE OBJECT 21111 OWNER TO testuser;

--
-- Name: 21112; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21112');


ALTER LARGE OBJECT 21112 OWNER TO testuser;

--
-- Name: 21371; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21371');


ALTER LARGE OBJECT 21371 OWNER TO testuser;

--
-- Name: 21372; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21372');


ALTER LARGE OBJECT 21372 OWNER TO testuser;

--
-- Name: 21373; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21373');


ALTER LARGE OBJECT 21373 OWNER TO testuser;

--
-- Name: 21374; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21374');


ALTER LARGE OBJECT 21374 OWNER TO testuser;

--
-- Name: 21375; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21375');


ALTER LARGE OBJECT 21375 OWNER TO testuser;

--
-- Name: 21376; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21376');


ALTER LARGE OBJECT 21376 OWNER TO testuser;

--
-- Name: 21377; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21377');


ALTER LARGE OBJECT 21377 OWNER TO testuser;

--
-- Name: 21384; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21384');


ALTER LARGE OBJECT 21384 OWNER TO testuser;

--
-- Name: 21385; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21385');


ALTER LARGE OBJECT 21385 OWNER TO testuser;

--
-- Name: 21441; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21441');


ALTER LARGE OBJECT 21441 OWNER TO testuser;

--
-- Name: 21442; Type: BLOB; Schema: -; Owner: testuser
--

SELECT pg_catalog.lo_create('21442');


ALTER LARGE OBJECT 21442 OWNER TO testuser;

--
-- Data for Name: tbl_common; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_common (id, body) FROM stdin;
\.
COPY tbl_common (id, body) FROM '$$PATH$$/2126.dat';

--
-- Data for Name: tbl_contactform; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_contactform (id, firstname, lastname, email, message, phone, language, ip, datecreated) FROM stdin;
\.
COPY tbl_contactform (id, firstname, lastname, email, message, phone, language, ip, datecreated) FROM '$$PATH$$/2135.dat';

--
-- Data for Name: tbl_newsletter; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_newsletter (email, ip, language, datecreated) FROM stdin;
\.
COPY tbl_newsletter (email, ip, language, datecreated) FROM '$$PATH$$/2133.dat';

--
-- Data for Name: tbl_order; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_order (id, iduser, status, delivery, firstname, lastname, email, phone, address, message, search, note, ip, price, count, iscompleted, ispaid, isremoved, datecreated, datecompleted, datepaid) FROM stdin;
\.
COPY tbl_order (id, iduser, status, delivery, firstname, lastname, email, phone, address, message, search, note, ip, price, count, iscompleted, ispaid, isremoved, datecreated, datecompleted, datepaid) FROM '$$PATH$$/2127.dat';

--
-- Data for Name: tbl_order_product; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_order_product (idorder, idproduct, name, reference, pictures, price, count) FROM stdin;
\.
COPY tbl_order_product (idorder, idproduct, name, reference, pictures, price, count) FROM '$$PATH$$/2128.dat';

--
-- Data for Name: tbl_page; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_page (id, parent, pictures, navigations, tags, template, language, name, url, search, icon, perex, title, priority, body, ispartial, isremoved, datecreated) FROM stdin;
\.
COPY tbl_page (id, parent, pictures, navigations, tags, template, language, name, url, search, icon, perex, title, priority, body, ispartial, isremoved, datecreated) FROM '$$PATH$$/2134.dat';

--
-- Data for Name: tbl_page_widget; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_page_widget (idpage, idwidget, settings) FROM stdin;
\.
COPY tbl_page_widget (idpage, idwidget, settings) FROM '$$PATH$$/2129.dat';

--
-- Data for Name: tbl_product; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_product (id, pictures, reference, linker, linker_category, category, name, search, price, body, istop, isremoved, datecreated, linker_manufacturer, manufacturer) FROM stdin;
\.
COPY tbl_product (id, pictures, reference, linker, linker_category, category, name, search, price, body, istop, isremoved, datecreated, linker_manufacturer, manufacturer) FROM '$$PATH$$/2130.dat';

--
-- Data for Name: tbl_user; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_user (id, idfacebook, idgoogle, idlinkedin, idinstagram, idyandex, iddropbox, idvk, idyahoo, idlive, ip, name, search, email, gender, countlogin, isremoved, datelogged, datecreated) FROM stdin;
\.
COPY tbl_user (id, idfacebook, idgoogle, idlinkedin, idinstagram, idyandex, iddropbox, idvk, idyahoo, idlive, ip, name, search, email, gender, countlogin, isremoved, datelogged, datecreated) FROM '$$PATH$$/2131.dat';

--
-- Data for Name: tbl_visitor; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_visitor (id, day, month, year, pages, hits, "unique", uniquemonth, count, search, direct, social, unknown, advert, desktop, mobile, visitors, users, orders, contactforms, newsletter, dateupdated, datecreated) FROM stdin;
\.
COPY tbl_visitor (id, day, month, year, pages, hits, "unique", uniquemonth, count, search, direct, social, unknown, advert, desktop, mobile, visitors, users, orders, contactforms, newsletter, dateupdated, datecreated) FROM '$$PATH$$/2136.dat';

--
-- Data for Name: tbl_widget; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_widget (id, name, icon, body, istemplate, datecreated, isremoved) FROM stdin;
\.
COPY tbl_widget (id, name, icon, body, istemplate, datecreated, isremoved) FROM '$$PATH$$/2132.dat';

--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: 
--

SET search_path = pg_catalog;

\i $$PATH$$/2153.dat

SET search_path = public, pg_catalog;

--
-- Name: tbl_common_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_common
    ADD CONSTRAINT tbl_common_pkey PRIMARY KEY (id);


--
-- Name: tbl_contactform_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_contactform
    ADD CONSTRAINT tbl_contactform_pkey PRIMARY KEY (id);


--
-- Name: tbl_newsletter_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_newsletter
    ADD CONSTRAINT tbl_newsletter_pkey PRIMARY KEY (email);


--
-- Name: tbl_order_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_order
    ADD CONSTRAINT tbl_order_pkey PRIMARY KEY (id);


--
-- Name: tbl_page_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_page
    ADD CONSTRAINT tbl_page_pkey PRIMARY KEY (id);


--
-- Name: tbl_product_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_product
    ADD CONSTRAINT tbl_product_pkey PRIMARY KEY (id);


--
-- Name: tbl_user_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_user
    ADD CONSTRAINT tbl_user_pkey PRIMARY KEY (id);


--
-- Name: tbl_visitor_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_visitor
    ADD CONSTRAINT tbl_visitor_pkey PRIMARY KEY (id);


--
-- Name: tbl_widget_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka; Tablespace: 
--

ALTER TABLE ONLY tbl_widget
    ADD CONSTRAINT tbl_widget_pkey PRIMARY KEY (id);


--
-- Name: tbl_page_url; Type: INDEX; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE INDEX tbl_page_url ON tbl_page USING btree (url);


--
-- Name: tbl_page_widget_id; Type: INDEX; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE INDEX tbl_page_widget_id ON tbl_page_widget USING btree (idpage, idwidget);


--
-- Name: tbl_product_linker; Type: INDEX; Schema: public; Owner: petersirka; Tablespace: 
--

CREATE INDEX tbl_product_linker ON tbl_product USING btree (linker, linker_category);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

