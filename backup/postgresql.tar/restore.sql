--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.1
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public.tbl_product_linker;
DROP INDEX public.tbl_page_widget_id;
DROP INDEX public.tbl_page_url;
ALTER TABLE ONLY public.tbl_widget DROP CONSTRAINT tbl_widget_pkey;
ALTER TABLE ONLY public.tbl_visitor DROP CONSTRAINT tbl_visitor_pkey;
ALTER TABLE ONLY public.tbl_user DROP CONSTRAINT tbl_user_pkey;
ALTER TABLE ONLY public.tbl_product DROP CONSTRAINT tbl_product_pkey;
ALTER TABLE ONLY public.tbl_post DROP CONSTRAINT tbl_post_pkey;
ALTER TABLE ONLY public.tbl_page DROP CONSTRAINT tbl_page_pkey;
ALTER TABLE ONLY public.tbl_order DROP CONSTRAINT tbl_order_pkey;
ALTER TABLE ONLY public.tbl_newsletter DROP CONSTRAINT tbl_newsletter_pkey;
ALTER TABLE ONLY public.tbl_contactform DROP CONSTRAINT tbl_contactform_pkey;
ALTER TABLE ONLY public.tbl_common DROP CONSTRAINT tbl_common_pkey;
SELECT pg_catalog.lo_unlink('2736002');
SELECT pg_catalog.lo_unlink('2736001');
SELECT pg_catalog.lo_unlink('2735989');
SELECT pg_catalog.lo_unlink('2735988');
SELECT pg_catalog.lo_unlink('2735987');
SELECT pg_catalog.lo_unlink('2735986');
SELECT pg_catalog.lo_unlink('2735985');
SELECT pg_catalog.lo_unlink('2735984');
SELECT pg_catalog.lo_unlink('2735983');
SELECT pg_catalog.lo_unlink('2735982');
SELECT pg_catalog.lo_unlink('2735981');
SELECT pg_catalog.lo_unlink('2735980');
SELECT pg_catalog.lo_unlink('2735979');
SELECT pg_catalog.lo_unlink('2735978');
SELECT pg_catalog.lo_unlink('2735977');
SELECT pg_catalog.lo_unlink('2735976');
SELECT pg_catalog.lo_unlink('2735975');
SELECT pg_catalog.lo_unlink('2735974');
SELECT pg_catalog.lo_unlink('2735973');
SELECT pg_catalog.lo_unlink('2735972');
SELECT pg_catalog.lo_unlink('2735971');
SELECT pg_catalog.lo_unlink('2735970');
SELECT pg_catalog.lo_unlink('2735969');
SELECT pg_catalog.lo_unlink('2735968');
SELECT pg_catalog.lo_unlink('18304');
SELECT pg_catalog.lo_unlink('18303');
SELECT pg_catalog.lo_unlink('18269');
SELECT pg_catalog.lo_unlink('18268');
SELECT pg_catalog.lo_unlink('18267');
SELECT pg_catalog.lo_unlink('18266');
SELECT pg_catalog.lo_unlink('18265');
SELECT pg_catalog.lo_unlink('18264');
SELECT pg_catalog.lo_unlink('18263');
SELECT pg_catalog.lo_unlink('18262');
SELECT pg_catalog.lo_unlink('18261');
SELECT pg_catalog.lo_unlink('18260');
SELECT pg_catalog.lo_unlink('18259');
SELECT pg_catalog.lo_unlink('18258');
SELECT pg_catalog.lo_unlink('18257');
SELECT pg_catalog.lo_unlink('18256');
SELECT pg_catalog.lo_unlink('18255');
SELECT pg_catalog.lo_unlink('18254');
SELECT pg_catalog.lo_unlink('18253');
SELECT pg_catalog.lo_unlink('18252');
SELECT pg_catalog.lo_unlink('18251');
SELECT pg_catalog.lo_unlink('18250');
SELECT pg_catalog.lo_unlink('18249');
SELECT pg_catalog.lo_unlink('18248');
DROP TABLE public.tbl_widget;
DROP TABLE public.tbl_visitor;
DROP TABLE public.tbl_user;
DROP TABLE public.tbl_product;
DROP TABLE public.tbl_post;
DROP TABLE public.tbl_page_widget;
DROP TABLE public.tbl_page;
DROP TABLE public.tbl_order_product;
DROP TABLE public.tbl_order;
DROP TABLE public.tbl_newsletter;
DROP TABLE public.tbl_contactform;
DROP TABLE public.tbl_common;
DROP EXTENSION xml2;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION unaccent;
DROP EXTENSION tablefunc;
DROP EXTENSION sslinfo;
DROP EXTENSION pgstattuple;
DROP EXTENSION pgrowlocks;
DROP EXTENSION pgcrypto;
DROP EXTENSION pg_trgm;
DROP EXTENSION pg_stat_statements;
DROP EXTENSION ltree;
DROP EXTENSION intarray;
DROP EXTENSION hstore;
DROP EXTENSION fuzzystrmatch;
DROP EXTENSION earthdistance;
DROP EXTENSION dict_xsyn;
DROP EXTENSION dict_int;
DROP EXTENSION dblink;
DROP EXTENSION cube;
DROP EXTENSION citext;
DROP EXTENSION btree_gist;
DROP EXTENSION btree_gin;
DROP EXTENSION plv8;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: plv8; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plv8 WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plv8; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plv8 IS 'PL/JavaScript (v8) trusted procedural language';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: cube; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS cube WITH SCHEMA public;


--
-- Name: EXTENSION cube; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION cube IS 'data type for multidimensional cubes';


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: dict_int; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dict_int WITH SCHEMA public;


--
-- Name: EXTENSION dict_int; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_int IS 'text search dictionary template for integers';


--
-- Name: dict_xsyn; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dict_xsyn WITH SCHEMA public;


--
-- Name: EXTENSION dict_xsyn; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dict_xsyn IS 'text search dictionary template for extended synonym processing';


--
-- Name: earthdistance; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS earthdistance WITH SCHEMA public;


--
-- Name: EXTENSION earthdistance; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION earthdistance IS 'calculate great-circle distances on the surface of the Earth';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: intarray; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS intarray WITH SCHEMA public;


--
-- Name: EXTENSION intarray; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION intarray IS 'functions, operators, and index support for 1-D arrays of integers';


--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: pgrowlocks; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgrowlocks WITH SCHEMA public;


--
-- Name: EXTENSION pgrowlocks; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgrowlocks IS 'show row-level locking information';


--
-- Name: pgstattuple; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgstattuple WITH SCHEMA public;


--
-- Name: EXTENSION pgstattuple; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgstattuple IS 'show tuple-level statistics';


--
-- Name: sslinfo; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS sslinfo WITH SCHEMA public;


--
-- Name: EXTENSION sslinfo; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION sslinfo IS 'information about SSL certificates';


--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: xml2; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS xml2 WITH SCHEMA public;


--
-- Name: EXTENSION xml2; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION xml2 IS 'XPath querying and XSLT';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tbl_common; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_common (
    id character varying(30) NOT NULL,
    body json
);


ALTER TABLE tbl_common OWNER TO petersirka;

--
-- Name: tbl_contactform; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_contactform (
    id character varying(20) NOT NULL,
    firstname character varying(40),
    lastname character varying(40),
    email character varying(200),
    message text,
    phone character varying(20),
    language character varying(3),
    ip character varying(80),
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_contactform OWNER TO petersirka;

--
-- Name: tbl_newsletter; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_newsletter (
    email character varying(200) NOT NULL,
    ip character varying(80),
    language character varying(3),
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_newsletter OWNER TO petersirka;

--
-- Name: tbl_order; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_order (
    id character varying(20) NOT NULL,
    iduser character varying(20),
    status character varying(100),
    number integer DEFAULT 0,
    delivery character varying(30),
    firstname character varying(40),
    lastname character varying(40),
    email character varying(200),
    phone character varying(20),
    address character varying(1000),
    message character varying(500),
    search character varying(80),
    note character varying(500),
    ip character varying(80),
    price real,
    count smallint,
    iscompleted boolean,
    ispaid boolean,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    datecompleted timestamp without time zone,
    datepaid timestamp without time zone,
    language character varying(3)
);


ALTER TABLE tbl_order OWNER TO petersirka;

--
-- Name: tbl_order_product; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_order_product (
    idorder character varying(20),
    idproduct character varying(20),
    name character varying(80),
    reference character varying(20),
    pictures character varying(100),
    price real DEFAULT 0,
    count smallint DEFAULT 0
);


ALTER TABLE tbl_order_product OWNER TO petersirka;

--
-- Name: tbl_page; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_page (
    id character varying(20) NOT NULL,
    parent character varying(20),
    pictures character varying(500),
    navigations character varying(1000),
    partial character varying(500),
    tags character varying(500),
    template character varying(30),
    language character varying(3),
    url character varying(200),
    icon character varying(20),
    name character varying(50),
    title character varying(100),
    search character varying(2000),
    keywords character varying(200),
    perex character varying(500),
    priority smallint DEFAULT (0)::smallint,
    body text,
    ispartial boolean DEFAULT false,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    dateupdated timestamp without time zone
);


ALTER TABLE tbl_page OWNER TO petersirka;

--
-- Name: tbl_page_widget; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_page_widget (
    idpage character varying(20),
    idwidget character varying(20),
    settings character varying(500)
);


ALTER TABLE tbl_page_widget OWNER TO petersirka;

--
-- Name: tbl_post; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_post (
    id character varying(20) NOT NULL,
    name character varying(80),
    linker character varying(80),
    category character varying(50),
    category_linker character varying(50),
    template character varying(30),
    language character varying(3),
    perex character varying(500),
    keywords character varying(200),
    tags character varying(500),
    search character varying(1000),
    pictures character varying(1000),
    body text,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    dateupdated timestamp without time zone
);


ALTER TABLE tbl_post OWNER TO petersirka;

--
-- Name: tbl_product; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_product (
    id character varying(20) NOT NULL,
    pictures character varying(500),
    reference character varying(20),
    linker character varying(300),
    linker_category character varying(300),
    linker_manufacturer character varying(50),
    category character varying(50),
    manufacturer character varying(50),
    name character varying(50),
    search character varying(80),
    price real DEFAULT 0,
    body text,
    istop boolean DEFAULT false,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    dateupdated timestamp without time zone
);


ALTER TABLE tbl_product OWNER TO petersirka;

--
-- Name: tbl_user; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_user (
    id character varying(20) NOT NULL,
    idfacebook character varying(30),
    idgoogle character varying(30),
    idlinkedin character varying(30),
    idinstagram character varying(30),
    idyandex character varying(30),
    iddropbox character varying(30),
    idvk character varying(30),
    idyahoo character varying(30),
    idlive character varying(30),
    ip character varying(80),
    name character varying(50),
    search character varying(80),
    email character varying(200),
    password character varying(50),
    firstname character varying(50),
    lastname character varying(50),
    gender character varying(20),
    countlogin integer DEFAULT 0,
    isblocked boolean DEFAULT false,
    isremoved boolean DEFAULT false,
    datelogged timestamp without time zone,
    datecreated timestamp without time zone DEFAULT now(),
    dateupdated timestamp without time zone
);


ALTER TABLE tbl_user OWNER TO petersirka;

--
-- Name: tbl_visitor; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_visitor (
    id character varying(20) NOT NULL,
    day smallint DEFAULT 0,
    month smallint DEFAULT 0,
    year smallint DEFAULT 0,
    pages integer DEFAULT 0,
    hits integer DEFAULT 0,
    "unique" integer DEFAULT 0,
    uniquemonth integer DEFAULT 0,
    count integer DEFAULT 0,
    search integer DEFAULT 0,
    direct integer DEFAULT 0,
    social integer DEFAULT 0,
    unknown integer DEFAULT 0,
    advert integer DEFAULT 0,
    desktop integer DEFAULT 0,
    mobile integer DEFAULT 0,
    visitors integer DEFAULT 0,
    users integer DEFAULT 0,
    orders integer DEFAULT 0,
    contactforms integer DEFAULT 0,
    newsletter integer DEFAULT 0,
    robots integer DEFAULT 0,
    fulltext integer DEFAULT 0,
    counter integer DEFAULT 0,
    dateupdated timestamp without time zone,
    datecreated timestamp without time zone DEFAULT now()
);


ALTER TABLE tbl_visitor OWNER TO petersirka;

--
-- Name: tbl_widget; Type: TABLE; Schema: public; Owner: petersirka
--

CREATE TABLE tbl_widget (
    id character varying(20) NOT NULL,
    name character varying(50),
    icon character varying(20),
    category character varying(50),
    body text,
    istemplate boolean,
    isremoved boolean DEFAULT false,
    datecreated timestamp without time zone DEFAULT now(),
    dateupdated timestamp without time zone
);


ALTER TABLE tbl_widget OWNER TO petersirka;

--
-- Name: 18248; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18248');


ALTER LARGE OBJECT 18248 OWNER TO petersirka;

--
-- Name: 18249; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18249');


ALTER LARGE OBJECT 18249 OWNER TO petersirka;

--
-- Name: 18250; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18250');


ALTER LARGE OBJECT 18250 OWNER TO petersirka;

--
-- Name: 18251; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18251');


ALTER LARGE OBJECT 18251 OWNER TO petersirka;

--
-- Name: 18252; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18252');


ALTER LARGE OBJECT 18252 OWNER TO petersirka;

--
-- Name: 18253; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18253');


ALTER LARGE OBJECT 18253 OWNER TO petersirka;

--
-- Name: 18254; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18254');


ALTER LARGE OBJECT 18254 OWNER TO petersirka;

--
-- Name: 18255; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18255');


ALTER LARGE OBJECT 18255 OWNER TO petersirka;

--
-- Name: 18256; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18256');


ALTER LARGE OBJECT 18256 OWNER TO petersirka;

--
-- Name: 18257; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18257');


ALTER LARGE OBJECT 18257 OWNER TO petersirka;

--
-- Name: 18258; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18258');


ALTER LARGE OBJECT 18258 OWNER TO petersirka;

--
-- Name: 18259; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18259');


ALTER LARGE OBJECT 18259 OWNER TO petersirka;

--
-- Name: 18260; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18260');


ALTER LARGE OBJECT 18260 OWNER TO petersirka;

--
-- Name: 18261; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18261');


ALTER LARGE OBJECT 18261 OWNER TO petersirka;

--
-- Name: 18262; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18262');


ALTER LARGE OBJECT 18262 OWNER TO petersirka;

--
-- Name: 18263; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18263');


ALTER LARGE OBJECT 18263 OWNER TO petersirka;

--
-- Name: 18264; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18264');


ALTER LARGE OBJECT 18264 OWNER TO petersirka;

--
-- Name: 18265; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18265');


ALTER LARGE OBJECT 18265 OWNER TO petersirka;

--
-- Name: 18266; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18266');


ALTER LARGE OBJECT 18266 OWNER TO petersirka;

--
-- Name: 18267; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18267');


ALTER LARGE OBJECT 18267 OWNER TO petersirka;

--
-- Name: 18268; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18268');


ALTER LARGE OBJECT 18268 OWNER TO petersirka;

--
-- Name: 18269; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18269');


ALTER LARGE OBJECT 18269 OWNER TO petersirka;

--
-- Name: 18303; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18303');


ALTER LARGE OBJECT 18303 OWNER TO petersirka;

--
-- Name: 18304; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('18304');


ALTER LARGE OBJECT 18304 OWNER TO petersirka;

--
-- Name: 2735968; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735968');


ALTER LARGE OBJECT 2735968 OWNER TO petersirka;

--
-- Name: 2735969; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735969');


ALTER LARGE OBJECT 2735969 OWNER TO petersirka;

--
-- Name: 2735970; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735970');


ALTER LARGE OBJECT 2735970 OWNER TO petersirka;

--
-- Name: 2735971; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735971');


ALTER LARGE OBJECT 2735971 OWNER TO petersirka;

--
-- Name: 2735972; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735972');


ALTER LARGE OBJECT 2735972 OWNER TO petersirka;

--
-- Name: 2735973; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735973');


ALTER LARGE OBJECT 2735973 OWNER TO petersirka;

--
-- Name: 2735974; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735974');


ALTER LARGE OBJECT 2735974 OWNER TO petersirka;

--
-- Name: 2735975; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735975');


ALTER LARGE OBJECT 2735975 OWNER TO petersirka;

--
-- Name: 2735976; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735976');


ALTER LARGE OBJECT 2735976 OWNER TO petersirka;

--
-- Name: 2735977; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735977');


ALTER LARGE OBJECT 2735977 OWNER TO petersirka;

--
-- Name: 2735978; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735978');


ALTER LARGE OBJECT 2735978 OWNER TO petersirka;

--
-- Name: 2735979; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735979');


ALTER LARGE OBJECT 2735979 OWNER TO petersirka;

--
-- Name: 2735980; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735980');


ALTER LARGE OBJECT 2735980 OWNER TO petersirka;

--
-- Name: 2735981; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735981');


ALTER LARGE OBJECT 2735981 OWNER TO petersirka;

--
-- Name: 2735982; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735982');


ALTER LARGE OBJECT 2735982 OWNER TO petersirka;

--
-- Name: 2735983; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735983');


ALTER LARGE OBJECT 2735983 OWNER TO petersirka;

--
-- Name: 2735984; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735984');


ALTER LARGE OBJECT 2735984 OWNER TO petersirka;

--
-- Name: 2735985; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735985');


ALTER LARGE OBJECT 2735985 OWNER TO petersirka;

--
-- Name: 2735986; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735986');


ALTER LARGE OBJECT 2735986 OWNER TO petersirka;

--
-- Name: 2735987; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735987');


ALTER LARGE OBJECT 2735987 OWNER TO petersirka;

--
-- Name: 2735988; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735988');


ALTER LARGE OBJECT 2735988 OWNER TO petersirka;

--
-- Name: 2735989; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2735989');


ALTER LARGE OBJECT 2735989 OWNER TO petersirka;

--
-- Name: 2736001; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2736001');


ALTER LARGE OBJECT 2736001 OWNER TO petersirka;

--
-- Name: 2736002; Type: BLOB; Schema: -; Owner: petersirka
--

SELECT pg_catalog.lo_create('2736002');


ALTER LARGE OBJECT 2736002 OWNER TO petersirka;

--
-- Data for Name: tbl_common; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_common (id, body) FROM stdin;
\.
COPY tbl_common (id, body) FROM '$$PATH$$/3504.dat';

--
-- Data for Name: tbl_contactform; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_contactform (id, firstname, lastname, email, message, phone, language, ip, datecreated) FROM stdin;
\.
COPY tbl_contactform (id, firstname, lastname, email, message, phone, language, ip, datecreated) FROM '$$PATH$$/3505.dat';

--
-- Data for Name: tbl_newsletter; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_newsletter (email, ip, language, datecreated) FROM stdin;
\.
COPY tbl_newsletter (email, ip, language, datecreated) FROM '$$PATH$$/3506.dat';

--
-- Data for Name: tbl_order; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_order (id, iduser, status, number, delivery, firstname, lastname, email, phone, address, message, search, note, ip, price, count, iscompleted, ispaid, isremoved, datecreated, datecompleted, datepaid, language) FROM stdin;
\.
COPY tbl_order (id, iduser, status, number, delivery, firstname, lastname, email, phone, address, message, search, note, ip, price, count, iscompleted, ispaid, isremoved, datecreated, datecompleted, datepaid, language) FROM '$$PATH$$/3515.dat';

--
-- Data for Name: tbl_order_product; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_order_product (idorder, idproduct, name, reference, pictures, price, count) FROM stdin;
\.
COPY tbl_order_product (idorder, idproduct, name, reference, pictures, price, count) FROM '$$PATH$$/3507.dat';

--
-- Data for Name: tbl_page; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_page (id, parent, pictures, navigations, partial, tags, template, language, url, icon, name, title, search, keywords, perex, priority, body, ispartial, isremoved, datecreated, dateupdated) FROM stdin;
\.
COPY tbl_page (id, parent, pictures, navigations, partial, tags, template, language, url, icon, name, title, search, keywords, perex, priority, body, ispartial, isremoved, datecreated, dateupdated) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: tbl_page_widget; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_page_widget (idpage, idwidget, settings) FROM stdin;
\.
COPY tbl_page_widget (idpage, idwidget, settings) FROM '$$PATH$$/3509.dat';

--
-- Data for Name: tbl_post; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_post (id, name, linker, category, category_linker, template, language, perex, keywords, tags, search, pictures, body, isremoved, datecreated, dateupdated) FROM stdin;
\.
COPY tbl_post (id, name, linker, category, category_linker, template, language, perex, keywords, tags, search, pictures, body, isremoved, datecreated, dateupdated) FROM '$$PATH$$/3510.dat';

--
-- Data for Name: tbl_product; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_product (id, pictures, reference, linker, linker_category, linker_manufacturer, category, manufacturer, name, search, price, body, istop, isremoved, datecreated, dateupdated) FROM stdin;
\.
COPY tbl_product (id, pictures, reference, linker, linker_category, linker_manufacturer, category, manufacturer, name, search, price, body, istop, isremoved, datecreated, dateupdated) FROM '$$PATH$$/3511.dat';

--
-- Data for Name: tbl_user; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_user (id, idfacebook, idgoogle, idlinkedin, idinstagram, idyandex, iddropbox, idvk, idyahoo, idlive, ip, name, search, email, password, firstname, lastname, gender, countlogin, isblocked, isremoved, datelogged, datecreated, dateupdated) FROM stdin;
\.
COPY tbl_user (id, idfacebook, idgoogle, idlinkedin, idinstagram, idyandex, iddropbox, idvk, idyahoo, idlive, ip, name, search, email, password, firstname, lastname, gender, countlogin, isblocked, isremoved, datelogged, datecreated, dateupdated) FROM '$$PATH$$/3514.dat';

--
-- Data for Name: tbl_visitor; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_visitor (id, day, month, year, pages, hits, "unique", uniquemonth, count, search, direct, social, unknown, advert, desktop, mobile, visitors, users, orders, contactforms, newsletter, robots, fulltext, counter, dateupdated, datecreated) FROM stdin;
\.
COPY tbl_visitor (id, day, month, year, pages, hits, "unique", uniquemonth, count, search, direct, social, unknown, advert, desktop, mobile, visitors, users, orders, contactforms, newsletter, robots, fulltext, counter, dateupdated, datecreated) FROM '$$PATH$$/3512.dat';

--
-- Data for Name: tbl_widget; Type: TABLE DATA; Schema: public; Owner: petersirka
--

COPY tbl_widget (id, name, icon, category, body, istemplate, isremoved, datecreated, dateupdated) FROM stdin;
\.
COPY tbl_widget (id, name, icon, category, body, istemplate, isremoved, datecreated, dateupdated) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: 
--

SET search_path = pg_catalog;

\i $$PATH$$/3564.dat

SET search_path = public, pg_catalog;

--
-- Name: tbl_common_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_common
    ADD CONSTRAINT tbl_common_pkey PRIMARY KEY (id);


--
-- Name: tbl_contactform_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_contactform
    ADD CONSTRAINT tbl_contactform_pkey PRIMARY KEY (id);


--
-- Name: tbl_newsletter_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_newsletter
    ADD CONSTRAINT tbl_newsletter_pkey PRIMARY KEY (email);


--
-- Name: tbl_order_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_order
    ADD CONSTRAINT tbl_order_pkey PRIMARY KEY (id);


--
-- Name: tbl_page_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_page
    ADD CONSTRAINT tbl_page_pkey PRIMARY KEY (id);


--
-- Name: tbl_post_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_post
    ADD CONSTRAINT tbl_post_pkey PRIMARY KEY (id);


--
-- Name: tbl_product_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_product
    ADD CONSTRAINT tbl_product_pkey PRIMARY KEY (id);


--
-- Name: tbl_user_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_user
    ADD CONSTRAINT tbl_user_pkey PRIMARY KEY (id);


--
-- Name: tbl_visitor_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_visitor
    ADD CONSTRAINT tbl_visitor_pkey PRIMARY KEY (id);


--
-- Name: tbl_widget_pkey; Type: CONSTRAINT; Schema: public; Owner: petersirka
--

ALTER TABLE ONLY tbl_widget
    ADD CONSTRAINT tbl_widget_pkey PRIMARY KEY (id);


--
-- Name: tbl_page_url; Type: INDEX; Schema: public; Owner: petersirka
--

CREATE INDEX tbl_page_url ON tbl_page USING btree (url);


--
-- Name: tbl_page_widget_id; Type: INDEX; Schema: public; Owner: petersirka
--

CREATE INDEX tbl_page_widget_id ON tbl_page_widget USING btree (idpage, idwidget);


--
-- Name: tbl_product_linker; Type: INDEX; Schema: public; Owner: petersirka
--

CREATE INDEX tbl_product_linker ON tbl_product USING btree (linker, linker_category);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

